nodeRequire('electron').remote.getCurrentWindow().setVibrancy('ultra-dark');

# vscode-transparent
transparent vscode css
